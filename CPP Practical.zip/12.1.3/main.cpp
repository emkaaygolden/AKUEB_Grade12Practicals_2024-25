#include <iostream>
using namespace std;

int main() {

    int num = 20;

    if (num > 10) {
        if (num % 2 == 0)
            cout << "Number is even and greater than 10\n";
    }


    return 0;
}
