#include <iostream>
using namespace std;

int main() {
	
    for (int i = 1; i <= 5; i++)
        cout << i << " ";
    cout << "\n";
    
	return 0;
}
