#include <iostream>
using namespace std;

int main() {
	
    int choice = 2;
    
	switch (choice) {
    case 1:
        cout << "Choice is 1\n";
        break;
    case 2:
        cout << "Choice is 2\n";
        break;
    default:
        cout << "Invalid choice\n";
    }
   
   
    return 0;
}
