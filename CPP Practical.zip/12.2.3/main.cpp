#include <iostream>
using namespace std;

int main() {
	
    int i = 1;
  
    while (i <= 5) {
        cout << i << " ";
        i++;
    }
    cout << "\n";
    return 0;
    
}
